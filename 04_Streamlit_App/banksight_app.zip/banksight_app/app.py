import streamlit as st

st.set_page_config(
    page_title="BankSight Dashboard",
    layout="wide"
)

st.title("🏦 BankSight Dashboard")
st.write("Use the sidebar to navigate")

